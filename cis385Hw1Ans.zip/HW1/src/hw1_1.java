/*
* BMCC CIS 485 - Web Programming
* Spring 2014
* Chris Chapman
* HW1
*
* hw1_1 Rectangle Problem
*
* Reads the length and width of a rectangle from a user
* and for output displays both its area and perimeter values.
*
*/

public class hw1_1 extends hw1 {

	public static void main(String[] args) {
		
		rectangleProblem();

	}

}
