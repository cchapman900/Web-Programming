/*
* BMCC CIS 485 - Web Programming
* Spring 2014
* Chris Chapman
* HW1
*
* hw1_2 Square Problem
*
* Reads the length and width of a rectangle from a user
* and for output displays both its area and perimeter values.
*
*/

public class hw1_2 extends hw1 {

	public static void main(String[] args) {
		
		squareProblem();

	}

}
